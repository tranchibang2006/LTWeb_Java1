# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.1/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.1/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.1/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

Mở Console (F12) trên trình duyệt bất kỳ tại địa chỉ http://localhost:8888, sau đó copy và dán mã JavaScript tương ứng với từng chức năng để thực thi.

1. Lấy tất cả sinh viên (GET)

JavaScript


fetch('http://localhost:8888/api/students')
  .then(res => res.json())
  .then(data => console.log('1. Tất cả sinh viên:', data));
2. Lấy sinh viên theo ID (GET)
(Thay 92f38830-bdb4-4fc2-8dc0-d5438b2455cb bằng ID UUID thực tế)

JavaScript


fetch('http://localhost:8888/api/students/92f38830-bdb4-4fc2-8dc0-d5438b2455cb')
  .then(res => res.json())
  .then(data => console.log('2. Sinh viên theo ID:', data));
3. Tìm theo mã sinh viên (GET)

JavaScript


fetch('http://localhost:8888/api/students/code/SV001')
  .then(res => res.json())
  .then(data => console.log('3. Sinh viên theo Mã SV:', data));
4. Tìm kiếm sinh viên theo từ khóa (GET)

JavaScript


fetch('http://localhost:8888/api/students/search?keyword=Anh')
  .then(res => res.json())
  .then(data => console.log('4. Kết quả tìm kiếm:', data));
5. Thêm mới sinh viên (POST)

JavaScript


fetch('http://localhost:8888/api/students', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    studentCode: 'SV099',
    fullName: 'Trần Văn Mới',
    email: 'vanmoi@gmail.com',
    phone: '0988776655',
    className: 'IT24B'
  })
})
  .then(res => res.json())
  .then(data => console.log('5. Thêm mới thành công:', data));
6. Cập nhật sinh viên (PUT)
(Thay 92f38830-bdb4-4fc2-8dc0-d5438b2455cb bằng ID UUID của sinh viên muốn sửa)

JavaScript


fetch('http://localhost:8888/api/students/92f38830-bdb4-4fc2-8dc0-d5438b2455cb', {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    studentCode: 'SV011',
    fullName: 'Nguyễn Văn Cập Nhật',
    email: 'cong@gmail.com',
    phone: '0999999999',
    className: 'IT24A'
  })
})
  .then(res => res.json())
  .then(data => console.log('6. Cập nhật thành công:', data));
7. Xóa 1 sinh viên (DELETE)
(Thay 92f38830-bdb4-4fc2-8dc0-d5438b2455cb bằng ID UUID của sinh viên muốn xóa)

JavaScript


fetch('http://localhost:8888/api/students/92f38830-bdb4-4fc2-8dc0-d5438b2455cb', {
  method: 'DELETE'
})
  .then(res => console.log('7. Trạng thái xóa 1 sinh viên:', res.status));
8. Xóa tất cả sinh viên (DELETE)

JavaScript


fetch('http://localhost:8888/api/students', {
  method: 'DELETE'
})
  .then(res => console.log('8. Trạng thái xóa tất cả sinh viên:', res.status));